package com.music.player.domain.use_case.welcomeMusicList

import com.music.player.domain.repository.MainRepository

// Class for fetching music list from mobile
class FetchMusicListUseCase constructor(
    private val repository: MainRepository
) {


}