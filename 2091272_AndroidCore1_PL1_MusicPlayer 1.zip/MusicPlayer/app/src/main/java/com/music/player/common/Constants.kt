package com.music.player.common

// Use it for common variables around the project
object Constants {

}