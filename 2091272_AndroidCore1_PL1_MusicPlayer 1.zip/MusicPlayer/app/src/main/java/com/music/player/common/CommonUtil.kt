package com.music.player.common

import android.content.Context

// Write all common functions here
open class CommonUtil {

    /* Function For Show Message As An Alert Dialog */
    fun showAlert(message: String, context: Context?) {
    }
}