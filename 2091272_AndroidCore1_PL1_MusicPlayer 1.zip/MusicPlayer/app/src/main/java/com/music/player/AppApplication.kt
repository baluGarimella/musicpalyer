package com.music.player

import android.app.Application

class AppApplication : Application()